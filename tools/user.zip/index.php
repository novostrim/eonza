<?php
/*
	Eonza
	(c) 2014 Novostrim, OOO. http://www.novostrim.com
	License: MIT
*/

require_once $_SERVER['DOCUMENT_ROOT'].'/eonza/index.php';

