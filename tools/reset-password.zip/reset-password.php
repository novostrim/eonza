<?php
/*
    Eonza
    (c) 2015 Novostrim, OOO. http://www.eonza.org
    License: MIT
*/

require_once 'ajax.php';
require_once APP_EONZA."ajax/ajax_common.php";

$pass = pass_generate( 6 );
$passmd = pass_md5( $pass, true );

if ( $db->update( ENZ_USERS, '', array( "pass=X'$passmd'" ), 1 ))
{
	cookie_set( 'iduser', 1, 120 );
	cookie_set( 'pass', md5( $pass ), 120 );
	print "Password: <b>$pass</b>";
	@unlink( __FILE__ );
	if ( file_exists( __FILE__ ))
		print "<br>Delete ".__FILE__.'!';
}
else
	print "Error: update ".ENZ_USERS;
