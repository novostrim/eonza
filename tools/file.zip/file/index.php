<?php

if ( !isset($_GET['id']))
	exit;

require_once $_SERVER['DOCUMENT_ROOT'].'/admin/conf.inc.php';
require_once $_SERVER['DOCUMENT_ROOT']."/eonza/app.inc.php";
require_once APP_EONZA.'ajax/ajax_common.php';

$fname = getstrict('id' );
$browser = 0;
$thumb = 0;
if ( strpos( $fname, '-' ) === false )
{
    if ( $fname[0] == 'i' )
    {
    	$browser = 1;
    	$fname = substr( $fname, 1 );
    }
    elseif ( $fname[0] == 't' )
    {
    	$browser = 1;
    	$thumb = 1;
    	$fname = substr( $fname, 1 );
    }
}
else
{
    $browser = 1;
    $basename = pathinfo( $fname, PATHINFO_FILENAME );
    $fname = substr( $basename, strrpos( $basename, '-' ) + 1 );
}
$id = (int)$fname;

if ( !$id )
	exit;
$public = isset( $SHARE_FILES ) ? $SHARE_FILES : array( 0 );
require_once APP_EONZA.'lib/files.php';
files_download( $id, $browser, $thumb, $public );

?>